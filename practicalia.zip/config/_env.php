<?php
// practicalia/config/env.php
$APP_ENV = 'production';
$DATABASE_URL = 'mysql://if0_40167683:oyCMnBRWjhNR@sql206.infinityfree.com:3306/if0_40167683_practicalia?charset=utf8mb4';
