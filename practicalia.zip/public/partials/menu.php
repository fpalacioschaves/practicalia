<?php
// practicalia/public/partials/menu.php
declare(strict_types=1);

require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$isAdmin    = require_role('admin');
$isProfesor = require_role('profesor');

// Detecta base URL según entorno (local vs hosting)
$host = $_SERVER['HTTP_HOST'] ?? '';
if ($host === 'localhost' || $host === '127.0.0.1') {
  // Tu ruta local (http://localhost/practicalia/public/...)
  $base = '/practicalia/public';
} else {
  // Hosting (https://practicalia.great-site.net/public/...)
  $base = '/public';
}

$path = $_SERVER['SCRIPT_NAME'] ?? '';
?>
<nav class="bg-white shadow mb-6">
  <div class="max-w-6xl mx-auto px-4">
    <div class="flex justify-between h-14 items-center">
      <div class="flex items-center space-x-6">
        <a href="<?= $base ?>/index.php" class="font-semibold text-gray-800">Practicalia</a>

        <?php if ($isAdmin): ?>
          <a href="<?= $base ?>/admin/usuarios/index.php"
             class="<?= str_contains($path,'/admin/usuarios/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Usuarios
          </a>

          <a href="<?= $base ?>/cursos/index.php"
             class="<?= str_contains($path,'/cursos/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Cursos
          </a>

          <a href="<?= $base ?>/alumnos/index.php"
             class="<?= str_contains($path,'/alumnos/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Alumnos
          </a>

          <a href="<?= $base ?>/empresas/index.php"
             class="<?= str_contains($path,'/empresas/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Empresas
          </a>

        <?php elseif ($isProfesor): ?>
          <a href="<?= $base ?>/alumnos/index.php"
             class="<?= str_contains($path,'/alumnos/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Alumnos
          </a>

          <a href="<?= $base ?>/empresas/index.php"
             class="<?= str_contains($path,'/empresas/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
            Empresas
          </a>
        <?php endif; ?>

        <a href="<?= $base ?>/perfil/edit.php"
           class="<?= str_contains($path,'/perfil/') ? 'text-black font-semibold' : 'text-gray-600' ?>">
          Mi perfil
        </a>
      </div>

      <div class="flex items-center gap-3 text-sm text-gray-700">
        <span><?= htmlspecialchars($user['nombre'] ?? '') ?></span>
        <a href="<?= $base ?>/logout.php" class="text-red-600 hover:underline">Salir</a>
      </div>
    </div>
  </div>
</nav>
