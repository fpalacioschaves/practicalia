<?php
// practicalia/public/cursos/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_admin.php';
require_once __DIR__ . '/../../lib/auth.php';

$search    = trim($_GET['q'] ?? '');
$hasSearch = ($search !== '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 10;
$offset    = ($page - 1) * $perPage;

$whereSql = 'WHERE 1=1';
if ($hasSearch) {
  // placeholders únicos
  $whereSql .= ' AND (c.nombre LIKE :q1 OR c.codigo LIKE :q2 OR CAST(c.anyo AS CHAR) LIKE :q3)';
}
$like = "%{$search}%";

/** total */
$sqlCount = "SELECT COUNT(*) AS c FROM cursos c $whereSql";
$stCount  = $pdo->prepare($sqlCount);
if ($hasSearch) {
  $stCount->bindValue(':q1', $like, PDO::PARAM_STR);
  $stCount->bindValue(':q2', $like, PDO::PARAM_STR);
  $stCount->bindValue(':q3', $like, PDO::PARAM_STR);
}
$stCount->execute();
$total = (int)($stCount->fetch()['c'] ?? 0);

/** listado */
$sql = "
SELECT 
  c.id, c.nombre, c.codigo, c.anyo, c.activo,
  GROUP_CONCAT(DISTINCT u.nombre, ' ', u.apellidos ORDER BY u.apellidos SEPARATOR ', ') AS profesores
FROM cursos c
LEFT JOIN cursos_profesores cp ON cp.curso_id = c.id
LEFT JOIN usuarios u ON u.id = cp.profesor_id AND u.deleted_at IS NULL
$whereSql
GROUP BY c.id, c.nombre, c.codigo, c.anyo, c.activo
ORDER BY c.id DESC
LIMIT :limit OFFSET :offset
";
$st = $pdo->prepare($sql);
if ($hasSearch) {
  $st->bindValue(':q1', $like, PDO::PARAM_STR);
  $st->bindValue(':q2', $like, PDO::PARAM_STR);
  $st->bindValue(':q3', $like, PDO::PARAM_STR);
}
$st->bindValue(':limit',  $perPage, PDO::PARAM_INT);
$st->bindValue(':offset', $offset,  PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll();

$totalPages = max(1, (int)ceil($total / $perPage));
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Cursos — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">

  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-6xl mx-auto p-4">
    <div class="mb-4 flex items-center justify-between">
      <form class="flex gap-2" method="get">
        <input name="q" value="<?= htmlspecialchars($search) ?>" class="rounded-xl border border-gray-300 p-2" placeholder="Buscar (nombre, código, año)">
        <button class="rounded-xl bg-black text-white px-4">Buscar</button>
      </form>
      <a href="./create.php" class="rounded-xl bg-black text-white px-4 py-2">Nuevo curso</a>
    </div>

    <div class="bg-white rounded-2xl shadow overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="text-left p-3">ID</th>
            <th class="text-left p-3">Nombre</th>
            <th class="text-left p-3">Código</th>
            <th class="text-left p-3">Año</th>
            <th class="text-left p-3">Profesores</th>
            <th class="text-left p-3">Activo</th>
            <th class="text-left p-3">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): $cid=(int)$r['id']; ?>
            <tr class="border-t">
              <td class="p-3"><?= $cid ?></td>
              <td class="p-3"><?= htmlspecialchars($r['nombre']) ?></td>
              <td class="p-3"><?= htmlspecialchars($r['codigo'] ?? '') ?></td>
              <td class="p-3"><?= htmlspecialchars((string)$r['anyo'] ?? '') ?></td>
              <td class="p-3"><?= htmlspecialchars($r['profesores'] ?? '') ?></td>
              <td class="p-3">
                <?php if ((int)$r['activo']===1): ?>
                  <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Sí</span>
                <?php else: ?>
                  <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-800">No</span>
                <?php endif; ?>
              </td>
              <td class="p-3 flex items-center gap-2">
                <a class="underline" href="./edit.php?id=<?= $cid ?>">Editar</a>
                <form method="post" action="./delete.php" onsubmit="return confirm('¿Eliminar este curso?');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                  <input type="hidden" name="id" value="<?= $cid ?>">
                  <button class="text-red-600 underline">Eliminar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$rows): ?>
            <tr><td class="p-3" colspan="7">Sin resultados.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="mt-4 flex gap-2">
        <?php for ($p=1; $p<=$totalPages; $p++): ?>
          <a href="?q=<?= urlencode($search) ?>&page=<?= $p ?>" class="px-3 py-1 rounded <?= $p===$page ? 'bg-black text-white' : 'bg-white border' ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </main>
</body>
</html>
