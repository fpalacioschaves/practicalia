<?php
// practicalia/public/empresas/create.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $nombre    = trim($_POST['nombre'] ?? '');
    $cif       = trim($_POST['cif'] ?? '');
    $nif       = trim($_POST['nif'] ?? '');
    $sector    = trim($_POST['sector'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $telefono  = trim($_POST['telefono'] ?? '');
    $web       = trim($_POST['web'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $ciudad    = trim($_POST['ciudad'] ?? '');
    $provincia = trim($_POST['provincia'] ?? '');
    $cp        = trim($_POST['codigo_postal'] ?? '');
    $activo    = (isset($_POST['activo']) && $_POST['activo'] === '1') ? 1 : 0;

    if ($nombre === '') throw new RuntimeException('El nombre es obligatorio.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new RuntimeException('Email no válido.');
    }
    if ($cp !== '' && !preg_match('/^[0-9A-Za-z -]{3,10}$/', $cp)) {
      throw new RuntimeException('Código postal no válido.');
    }

    // NIF único si viene informado (la tabla tiene UNIQUE en nif)
    if ($nif !== '') {
      $stN = $pdo->prepare('SELECT 1 FROM empresas WHERE nif = :nif AND deleted_at IS NULL LIMIT 1');
      $stN->execute([':nif'=>$nif]);
      if ($stN->fetch()) throw new RuntimeException('Ya existe una empresa con ese NIF.');
    }

    $st = $pdo->prepare('
      INSERT INTO empresas
        (nombre, cif, nif, email, telefono, web, direccion, ciudad, provincia, codigo_postal, sector, activo)
      VALUES
        (:nombre, :cif, :nif, :email, :telefono, :web, :direccion, :ciudad, :provincia, :cp, :sector, :activo)
    ');
    $st->execute([
      ':nombre'=>$nombre,
      ':cif'=>($cif!==''?$cif:null),
      ':nif'=>($nif!==''?$nif:null),
      ':email'=>($email!==''?$email:null),
      ':telefono'=>($telefono!==''?$telefono:null),
      ':web'=>($web!==''?$web:null),
      ':direccion'=>($direccion!==''?$direccion:null),
      ':ciudad'=>($ciudad!==''?$ciudad:null),
      ':provincia'=>($provincia!==''?$provincia:null),
      ':cp'=>($cp!==''?$cp:null),
      ':sector'=>($sector!==''?$sector:null),
      ':activo'=>$activo
    ]);

    header('Location: ./index.php');
    exit;

  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Nueva empresa — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-3xl mx-auto p-4">
    <h1 class="text-xl font-semibold mb-4">Nueva empresa</h1>

    <?php if ($error): ?>
      <div class="mb-3 bg-red-50 text-red-700 p-3 rounded"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" class="bg-white p-6 rounded-2xl shadow space-y-4">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">

      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Nombre *</label>
          <input name="nombre" required class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Sector</label>
          <input name="sector" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label class="block text-sm font-medium">CIF</label>
          <input name="cif" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">NIF</label>
          <input name="nif" class="mt-1 w-full border rounded-xl p-2" placeholder="Único si se informa">
        </div>
        <div>
          <label class="block text-sm font-medium">Teléfono</label>
          <input name="telefono" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label class="block text-sm font-medium">Email</label>
          <input name="email" type="email" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Web</label>
          <input name="web" class="mt-1 w-full border rounded-xl p-2" placeholder="https://...">
        </div>
        <div>
          <label class="block text-sm font-medium">Código postal</label>
          <input name="codigo_postal" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium">Dirección</label>
        <input name="direccion" class="mt-1 w-full border rounded-xl p-2">
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Ciudad</label>
          <input name="ciudad" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Provincia</label>
          <input name="provincia" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="flex items-center gap-2">
        <input type="hidden" name="activo" value="0">
        <input type="checkbox" name="activo" id="activo" value="1" checked>
        <label for="activo" class="text-sm">Empresa activa</label>
      </div>

      <div class="flex gap-2">
        <button class="rounded-xl bg-black text-white px-4 py-2">Guardar</button>
        <a href="./index.php" class="rounded-xl px-4 py-2 border">Cancelar</a>
      </div>
    </form>
  </main>
</body>
</html>
