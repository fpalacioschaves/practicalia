<?php
// practicalia/public/empresas/delete.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405); exit('Método no permitido');
}

try {
  csrf_check($_POST['csrf'] ?? null);
  $id = (int)($_POST['id'] ?? 0);
  if ($id <= 0) throw new RuntimeException('ID inválido');

  // Borrado en cascada gracias a FKs: empresa_alumnos y empresa_contactos se eliminan solos
  $pdo->prepare('DELETE FROM empresas WHERE id = :id')->execute([':id'=>$id]);

  header('Location: ./index.php');
  exit;

} catch (Throwable $e) {
  http_response_code(400);
  exit('Error: ' . $e->getMessage());
}
