<?php
// practicalia/public/empresas/edit.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$isAdmin = require_role('admin');
$profId  = (int)($user['id'] ?? 0);

$idGet  = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$idPost = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$id     = $idPost ?: $idGet;
if (!$id || $id <= 0) { http_response_code(400); exit('ID inválido'); }

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['accion'] ?? '') === 'guardar_empresa') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $nombre    = trim($_POST['nombre'] ?? '');
    $cif       = trim($_POST['cif'] ?? '');
    $nif       = trim($_POST['nif'] ?? '');
    $sector    = trim($_POST['sector'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $telefono  = trim($_POST['telefono'] ?? '');
    $web       = trim($_POST['web'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $ciudad    = trim($_POST['ciudad'] ?? '');
    $provincia = trim($_POST['provincia'] ?? '');
    $cp        = trim($_POST['codigo_postal'] ?? '');
    $activo    = (isset($_POST['activo']) && $_POST['activo'] === '1') ? 1 : 0;

    if ($nombre === '') throw new RuntimeException('El nombre es obligatorio.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new RuntimeException('Email no válido.');
    }
    if ($cp !== '' && !preg_match('/^[0-9A-Za-z -]{3,10}$/', $cp)) {
      throw new RuntimeException('Código postal no válido.');
    }

    // NIF único (permitiendo el de la propia empresa)
    if ($nif !== '') {
      $stN = $pdo->prepare('SELECT 1 FROM empresas WHERE nif = :nif AND id <> :id AND deleted_at IS NULL LIMIT 1');
      $stN->execute([':nif'=>$nif, ':id'=>$id]);
      if ($stN->fetch()) throw new RuntimeException('Ya existe otra empresa con ese NIF.');
    }

    $st = $pdo->prepare('
      UPDATE empresas SET
        nombre=:nombre, cif=:cif, nif=:nif, email=:email, telefono=:tel, web=:web,
        direccion=:dir, ciudad=:ciudad, provincia=:provincia, codigo_postal=:cp,
        sector=:sector, activo=:activo
      WHERE id=:id
    ');
    $st->execute([
      ':nombre'=>$nombre,
      ':cif'=>($cif!==''?$cif:null),
      ':nif'=>($nif!==''?$nif:null),
      ':email'=>($email!==''?$email:null),
      ':tel'=>($telefono!==''?$telefono:null),
      ':web'=>($web!==''?$web:null),
      ':dir'=>($direccion!==''?$direccion:null),
      ':ciudad'=>($ciudad!==''?$ciudad:null),
      ':provincia'=>($provincia!==''?$provincia:null),
      ':cp'=>($cp!==''?$cp:null),
      ':sector'=>($sector!==''?$sector:null),
      ':activo'=>$activo,
      ':id'=>$id
    ]);

    header('Location: ./edit.php?id='.$id);
    exit;

  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}

/** Cargar empresa */
$stE = $pdo->prepare('SELECT * FROM empresas WHERE id = :id AND deleted_at IS NULL LIMIT 1');
$stE->execute([':id'=>$id]);
$empresa = $stE->fetch();
if (!$empresa) { http_response_code(404); exit('Empresa no encontrada'); }

/** Alumnos asociados a la empresa */
$stAE = $pdo->prepare('
  SELECT a.id, a.nombre, a.apellidos, a.email
  FROM alumnos a
  JOIN empresa_alumnos ea ON ea.alumno_id = a.id
  WHERE ea.empresa_id = :id
  ORDER BY a.apellidos, a.nombre
');
$stAE->execute([':id'=>$id]);
$alumnosEmpresa = $stAE->fetchAll();

/** Selector de alumnos disponibles (según rol) */
if ($isAdmin) {
  $stAll = $pdo->prepare('
    SELECT a.id, a.nombre, a.apellidos
    FROM alumnos a
    WHERE a.deleted_at IS NULL AND a.activo = 1
      AND a.id NOT IN (SELECT alumno_id FROM empresa_alumnos WHERE empresa_id = :id)
    ORDER BY a.apellidos, a.nombre
  ');
  $stAll->execute([':id'=>$id]);
  $alumnosDisponibles = $stAll->fetchAll();
} else {
  $stP = $pdo->prepare('
    SELECT DISTINCT a.id, a.nombre, a.apellidos
    FROM alumnos a
    JOIN alumnos_cursos ac ON ac.alumno_id = a.id
    JOIN cursos_profesores cp ON cp.curso_id = ac.curso_id AND cp.profesor_id = :pid
    WHERE a.deleted_at IS NULL AND a.activo = 1
      AND a.id NOT IN (SELECT alumno_id FROM empresa_alumnos WHERE empresa_id = :id)
    ORDER BY a.apellidos, a.nombre
  ');
  $stP->execute([':pid'=>$profId, ':id'=>$id]);
  $alumnosDisponibles = $stP->fetchAll();
}

/** Contactos de la empresa */
$stC = $pdo->prepare('
  SELECT ec.id, ec.fecha, ec.tipo, ec.resumen, ec.notas,
         u.nombre AS prof_nombre, u.apellidos AS prof_apellidos, u.id AS prof_id
  FROM empresa_contactos ec
  JOIN usuarios u ON u.id = ec.profesor_id
  WHERE ec.empresa_id = :id
  ORDER BY ec.fecha DESC, ec.id DESC
');
$stC->execute([':id'=>$id]);
$contactos = $stC->fetchAll();

/** Dirección completa para el mapa */
$addrParts = array_filter([
  $empresa['direccion'] ?? '',
  $empresa['codigo_postal'] ?? '',
  $empresa['ciudad'] ?? '',
  $empresa['provincia'] ?? '',
]);
$direccionCompleta = implode(', ', $addrParts);
$mapSrc = $direccionCompleta !== ''
  ? 'https://www.google.com/maps?q=' . urlencode($direccionCompleta) . '&output=embed'
  : null;
$mapLink = $direccionCompleta !== ''
  ? 'https://www.google.com/maps/search/?api=1&query=' . urlencode($direccionCompleta)
  : null;
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Editar empresa — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-6xl mx-auto p-4">
    <h1 class="text-xl font-semibold mb-4">
      Editar empresa #<?= (int)$empresa['id'] ?> — <?= htmlspecialchars($empresa['nombre']) ?>
    </h1>

    <?php if ($error): ?>
      <div class="mb-3 bg-red-50 text-red-700 p-3 rounded"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- FORM DATOS EMPRESA -->
    <form method="post" class="bg-white p-6 rounded-2xl shadow space-y-4 mb-8">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
      <input type="hidden" name="id" value="<?= (int)$empresa['id'] ?>">
      <input type="hidden" name="accion" value="guardar_empresa">

      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Nombre *</label>
          <input name="nombre" value="<?= htmlspecialchars($empresa['nombre']) ?>" required class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Sector</label>
          <input name="sector" value="<?= htmlspecialchars($empresa['sector'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label class="block text-sm font-medium">CIF</label>
          <input name="cif" value="<?= htmlspecialchars($empresa['cif'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">NIF</label>
          <input name="nif" value="<?= htmlspecialchars($empresa['nif'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Teléfono</label>
          <input name="telefono" value="<?= htmlspecialchars($empresa['telefono'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label class="block text-sm font-medium">Email</label>
          <input name="email" type="email" value="<?= htmlspecialchars($empresa['email'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Web</label>
          <input name="web" value="<?= htmlspecialchars($empresa['web'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2" placeholder="https://...">
        </div>
        <div>
          <label class="block text-sm font-medium">Código postal</label>
          <input name="codigo_postal" value="<?= htmlspecialchars($empresa['codigo_postal'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium">Dirección</label>
        <input name="direccion" value="<?= htmlspecialchars($empresa['direccion'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Ciudad</label>
          <input name="ciudad" value="<?= htmlspecialchars($empresa['ciudad'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Provincia</label>
          <input name="provincia" value="<?= htmlspecialchars($empresa['provincia'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="flex items-center gap-2">
        <input type="hidden" name="activo" value="0">
        <input type="checkbox" name="activo" id="activo" value="1" <?= ((int)($empresa['activo'] ?? 1)===1)?'checked':'' ?>>
        <label for="activo" class="text-sm">Empresa activa</label>
      </div>

      <div class="flex gap-2">
        <button class="rounded-xl bg-black text-white px-4 py-2">Guardar</button>
        <a href="./index.php" class="rounded-xl px-4 py-2 border">Volver</a>
      </div>
    </form>

    <!-- BLOQUE: MAPA DE LOCALIZACIÓN -->
    <section class="bg-white p-6 rounded-2xl shadow mb-8">
      <h2 class="font-semibold mb-3">Mapa</h2>
      <?php if ($mapSrc): ?>
        <div class="aspect-video w-full overflow-hidden rounded-2xl border">
          <iframe
            src="<?= htmlspecialchars($mapSrc) ?>"
            class="w-full h-full"
            style="border:0;"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
            allowfullscreen>
          </iframe>
        </div>
        <div class="mt-2 text-sm">
          <span class="text-gray-600"><?= htmlspecialchars($direccionCompleta) ?></span>
          ·
          <a href="<?= htmlspecialchars($mapLink) ?>" target="_blank" class="underline">Abrir en Google Maps</a>
        </div>
      <?php else: ?>
        <p class="text-sm text-gray-600">Añade la dirección, ciudad y provincia para ver el mapa aquí.</p>
      <?php endif; ?>
    </section>

    <!-- ASOCIACIÓN DE ALUMNOS -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Alumnos en esta empresa</h2>
        <ul class="space-y-2">
          <?php foreach ($alumnosEmpresa as $a): ?>
            <li class="flex items-center justify-between">
              <span><?= htmlspecialchars($a['apellidos'] . ', ' . $a['nombre']) ?> <span class="text-xs text-gray-500"><?= htmlspecialchars($a['email'] ?? '') ?></span></span>
              <form method="post" action="./alumno_remove.php" onsubmit="return confirm('Quitar alumno de la empresa?');">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                <input type="hidden" name="empresa_id" value="<?= (int)$empresa['id'] ?>">
                <input type="hidden" name="alumno_id" value="<?= (int)$a['id'] ?>">
                <button class="text-red-600 underline text-sm">Quitar</button>
              </form>
            </li>
          <?php endforeach; ?>
          <?php if (!$alumnosEmpresa): ?>
            <li class="text-sm text-gray-500">Sin alumnos asociados.</li>
          <?php endif; ?>
        </ul>
      </div>

      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Añadir alumno</h2>
        <form method="post" action="./alumno_add.php" class="flex gap-2">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
          <input type="hidden" name="empresa_id" value="<?= (int)$empresa['id'] ?>">
          <select name="alumno_id" class="border rounded-xl p-2 flex-1">
            <?php foreach ($alumnosDisponibles as $a): ?>
              <option value="<?= (int)$a['id'] ?>"><?= htmlspecialchars($a['apellidos'] . ', ' . $a['nombre']) ?></option>
            <?php endforeach; ?>
          </select>
          <button class="rounded-xl bg-black text-white px-4">Añadir</button>
        </form>
        <?php if (!$alumnosDisponibles): ?>
          <p class="mt-2 text-xs text-gray-500">No hay alumnos disponibles para asociar.</p>
        <?php endif; ?>
      </div>
    </section>

    <!-- DIARIO DE CONTACTOS -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Diario de contactos</h2>
        <ul class="space-y-3">
          <?php foreach ($contactos as $c): ?>
            <li class="border rounded-xl p-3">
              <div class="flex items-center justify-between text-sm">
                <div>
                  <span class="font-medium"><?= htmlspecialchars($c['prof_apellidos'] . ', ' . $c['prof_nombre']) ?></span>
                  · <span class="text-gray-500"><?= htmlspecialchars($c['tipo']) ?></span>
                  · <span class="text-gray-500"><?= htmlspecialchars($c['fecha']) ?></span>
                </div>
                <?php if ($isAdmin || (int)$c['prof_id'] === $profId): ?>
                  <form method="post" action="./contacto_delete.php" onsubmit="return confirm('¿Eliminar contacto?');">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="empresa_id" value="<?= (int)$empresa['id'] ?>">
                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <button class="text-red-600 underline text-xs">Eliminar</button>
                  </form>
                <?php endif; ?>
              </div>
              <div class="mt-2 font-medium"><?= htmlspecialchars($c['resumen']) ?></div>
              <?php if (!empty($c['notas'])): ?>
                <div class="mt-1 text-sm text-gray-700 whitespace-pre-line"><?= htmlspecialchars($c['notas']) ?></div>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
          <?php if (!$contactos): ?>
            <li class="text-sm text-gray-500">Aún no hay contactos.</li>
          <?php endif; ?>
        </ul>
      </div>

      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Añadir contacto</h2>
        <form method="post" action="./contacto_create.php" class="space-y-3">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
          <input type="hidden" name="empresa_id" value="<?= (int)$empresa['id'] ?>">

          <div>
            <label class="block text-sm font-medium">Tipo</label>
            <select name="tipo" class="mt-1 w-full border rounded-xl p-2">
              <option value="llamada">Llamada</option>
              <option value="email">Email</option>
              <option value="visita">Visita</option>
              <option value="otro">Otro</option>
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium">Resumen *</label>
            <input name="resumen" required class="mt-1 w-full border rounded-xl p-2" placeholder="Asunto breve">
          </div>

          <div>
            <label class="block text-sm font-medium">Notas</label>
            <textarea name="notas" rows="4" class="mt-1 w-full border rounded-xl p-2" placeholder="Detalles..."></textarea>
          </div>

          <button class="rounded-xl bg-black text-white px-4 py-2">Guardar contacto</button>
        </form>
      </div>
    </section>
  </main>
</body>
</html>
