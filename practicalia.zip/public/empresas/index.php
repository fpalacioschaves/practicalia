<?php
// practicalia/public/empresas/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$isAdmin = require_role('admin');

$search    = trim($_GET['q'] ?? '');
$hasSearch = ($search !== '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 10;
$offset    = ($page - 1) * $perPage;

$whereSql = 'WHERE e.deleted_at IS NULL';
if ($hasSearch) {
  $whereSql .= ' AND (e.nombre LIKE :q1 OR e.cif LIKE :q2 OR e.sector LIKE :q3)';
}
$like = "%{$search}%";

/** total */
$sqlCount = "SELECT COUNT(*) AS c FROM empresas e $whereSql";
$stC = $pdo->prepare($sqlCount);
if ($hasSearch) {
  $stC->bindValue(':q1', $like, PDO::PARAM_STR);
  $stC->bindValue(':q2', $like, PDO::PARAM_STR);
  $stC->bindValue(':q3', $like, PDO::PARAM_STR);
}
$stC->execute();
$total = (int)($stC->fetch()['c'] ?? 0);

/** listado */
$sql = "
SELECT 
  e.id, e.nombre, e.cif, e.sector, e.email, e.telefono, e.web, e.activo,
  COUNT(DISTINCT ea.alumno_id) AS total_alumnos,
  COUNT(DISTINCT ec.id) AS total_contactos
FROM empresas e
LEFT JOIN empresa_alumnos ea ON ea.empresa_id = e.id
LEFT JOIN empresa_contactos ec ON ec.empresa_id = e.id
$whereSql
GROUP BY e.id, e.nombre, e.cif, e.sector, e.email, e.telefono, e.web, e.activo
ORDER BY e.id DESC
LIMIT :limit OFFSET :offset
";
$st = $pdo->prepare($sql);
if ($hasSearch) {
  $st->bindValue(':q1', $like, PDO::PARAM_STR);
  $st->bindValue(':q2', $like, PDO::PARAM_STR);
  $st->bindValue(':q3', $like, PDO::PARAM_STR);
}
$st->bindValue(':limit', $perPage, PDO::PARAM_INT);
$st->bindValue(':offset', $offset, PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll();

$totalPages = max(1, (int)ceil($total / $perPage));
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Empresas — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-6xl mx-auto p-4">
    <div class="mb-4 flex items-center justify-between">
      <form class="flex gap-2" method="get">
        <input name="q" value="<?= htmlspecialchars($search) ?>" class="rounded-xl border border-gray-300 p-2" placeholder="Buscar (nombre, CIF, sector)">
        <button class="rounded-xl bg-black text-white px-4">Buscar</button>
      </form>
      <a href="./create.php" class="rounded-xl bg-black text-white px-4 py-2">Nueva empresa</a>
    </div>

    <div class="bg-white rounded-2xl shadow overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="text-left p-3">ID</th>
            <th class="text-left p-3">Nombre</th>
            <th class="text-left p-3">CIF</th>
            <th class="text-left p-3">Sector</th>
            <th class="text-left p-3">Alumnos</th>
            <th class="text-left p-3">Contactos</th>
            <th class="text-left p-3">Activo</th>
            <th class="text-left p-3">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): $id=(int)$r['id']; ?>
            <tr class="border-t">
              <td class="p-3"><?= $id ?></td>
              <td class="p-3">
                <a href="./edit.php?id=<?= $id ?>" class="text-gray-900 hover:underline">
                  <?= htmlspecialchars($r['nombre']) ?>
                </a>
                <div class="text-xs text-gray-500"><?= htmlspecialchars($r['web'] ?? '') ?></div>
              </td>
              <td class="p-3"><?= htmlspecialchars($r['cif'] ?? '') ?></td>
              <td class="p-3"><?= htmlspecialchars($r['sector'] ?? '') ?></td>
              <td class="p-3"><?= (int)$r['total_alumnos'] ?></td>
              <td class="p-3"><?= (int)$r['total_contactos'] ?></td>
              <td class="p-3">
                <?php if ((int)$r['activo']===1): ?>
                  <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Sí</span>
                <?php else: ?>
                  <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-800">No</span>
                <?php endif; ?>
              </td>
              <td class="p-3 flex items-center gap-2">
                <a class="underline" href="./edit.php?id=<?= $id ?>">Editar</a>
                <form method="post" action="./delete.php" onsubmit="return confirm('¿Eliminar esta empresa?');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                  <input type="hidden" name="id" value="<?= $id ?>">
                  <button class="text-red-600 underline">Eliminar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$rows): ?>
            <tr><td class="p-3" colspan="8">Sin resultados.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="mt-4 flex gap-2">
        <?php for ($p=1; $p<=$totalPages; $p++): ?>
          <a href="?q=<?= urlencode($search) ?>&page=<?= $p ?>" class="px-3 py-1 rounded <?= $p===$page ? 'bg-black text-white' : 'bg-white border' ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </main>
</body>
</html>
