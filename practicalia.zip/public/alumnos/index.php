<?php
// practicalia/public/alumnos/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$isAdmin = require_role('admin');
$profId  = (int)($user['id'] ?? 0);

$search    = trim($_GET['q'] ?? '');
$hasSearch = ($search !== '');
$page      = max(1, (int)($_GET['page'] ?? 1));
$perPage   = 10;
$offset    = ($page - 1) * $perPage;

// Base WHERE según rol
if ($isAdmin) {
    $fromJoin = "
        FROM alumnos a
        LEFT JOIN alumnos_cursos ac ON ac.alumno_id = a.id
        LEFT JOIN cursos c ON c.id = ac.curso_id
    ";
    $whereSql = "WHERE a.deleted_at IS NULL";
} else {
    $fromJoin = "
        FROM alumnos a
        JOIN alumnos_cursos ac ON ac.alumno_id = a.id
        JOIN cursos c ON c.id = ac.curso_id
        JOIN cursos_profesores cp ON cp.curso_id = c.id AND cp.profesor_id = :pid
    ";
    $whereSql = "WHERE a.deleted_at IS NULL";
}

if ($hasSearch) {
    // placeholders únicos (evita HY093)
    $whereSql .= " AND (a.nombre LIKE :q1 OR a.apellidos LIKE :q2 OR a.email LIKE :q3)";
}
$like = "%{$search}%";

/** ------ total ------ */
$sqlCount = "SELECT COUNT(DISTINCT a.id) AS c $fromJoin $whereSql";
$stCount = $pdo->prepare($sqlCount);
if (!$isAdmin) {
    $stCount->bindValue(':pid', $profId, PDO::PARAM_INT);
}
if ($hasSearch) {
    $stCount->bindValue(':q1', $like, PDO::PARAM_STR);
    $stCount->bindValue(':q2', $like, PDO::PARAM_STR);
    $stCount->bindValue(':q3', $like, PDO::PARAM_STR);
}
$stCount->execute();
$total = (int)($stCount->fetch()['c'] ?? 0);

/** ------ lista ------ */
$sqlList = "
SELECT 
  a.id, a.nombre, a.apellidos, a.email, a.telefono, a.activo,
  GROUP_CONCAT(DISTINCT c.nombre ORDER BY c.nombre SEPARATOR ', ') AS cursos
$fromJoin
$whereSql
GROUP BY a.id, a.nombre, a.apellidos, a.email, a.telefono, a.activo
ORDER BY a.id DESC
LIMIT :limit OFFSET :offset
";
$st = $pdo->prepare($sqlList);
if (!$isAdmin) {
    $st->bindValue(':pid', $profId, PDO::PARAM_INT);
}
if ($hasSearch) {
    $st->bindValue(':q1', $like, PDO::PARAM_STR);
    $st->bindValue(':q2', $like, PDO::PARAM_STR);
    $st->bindValue(':q3', $like, PDO::PARAM_STR);
}
$st->bindValue(':limit',  $perPage, PDO::PARAM_INT);
$st->bindValue(':offset', $offset,  PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll();

$totalPages = max(1, (int)ceil($total / $perPage));
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Alumnos — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-6xl mx-auto p-4">
    <div class="mb-4 flex items-center justify-between">
      <form class="flex gap-2" method="get">
        <input name="q" value="<?= htmlspecialchars($search) ?>" class="rounded-xl border border-gray-300 p-2" placeholder="Buscar (nombre, apellidos, email)">
        <button class="rounded-xl bg-black text-white px-4">Buscar</button>
      </form>
      <a href="./create.php" class="rounded-xl bg-black text-white px-4 py-2">Nuevo alumno</a>
    </div>

    <div class="bg-white rounded-2xl shadow overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-100">
          <tr>
            <th class="text-left p-3">ID</th>
            <th class="text-left p-3">Nombre</th>
            <th class="text-left p-3">Email</th>
            <th class="text-left p-3">Teléfono</th>
            <th class="text-left p-3">Cursos</th>
            <th class="text-left p-3">Activo</th>
            <th class="text-left p-3">Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): $aid=(int)$r['id']; ?>
            <tr class="border-t">
              <td class="p-3"><?= $aid ?></td>
              <td class="p-3"><?= htmlspecialchars($r['nombre'] . ' ' . $r['apellidos']) ?></td>
              <td class="p-3"><?= htmlspecialchars($r['email'] ?? '') ?></td>
              <td class="p-3"><?= htmlspecialchars($r['telefono'] ?? '') ?></td>
              <td class="p-3"><?= htmlspecialchars($r['cursos'] ?? '') ?></td>
              <td class="p-3">
                <?php if ((int)$r['activo']===1): ?>
                  <span class="px-2 py-1 text-xs rounded bg-green-100 text-green-800">Sí</span>
                <?php else: ?>
                  <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-800">No</span>
                <?php endif; ?>
              </td>
              <td class="p-3 flex items-center gap-2">
                <a class="underline" href="./edit.php?id=<?= $aid ?>">Editar</a>
                <form method="post" action="./delete.php" onsubmit="return confirm('¿Eliminar este alumno?');">
                  <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                  <input type="hidden" name="id" value="<?= $aid ?>">
                  <button class="text-red-600 underline">Eliminar</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$rows): ?>
            <tr><td class="p-3" colspan="7">Sin resultados.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
      <div class="mt-4 flex gap-2">
        <?php for ($p=1; $p<=$totalPages; $p++): ?>
          <a href="?q=<?= urlencode($search) ?>&page=<?= $p ?>" class="px-3 py-1 rounded <?= $p===$page ? 'bg-black text-white' : 'bg-white border' ?>"><?= $p ?></a>
        <?php endfor; ?>
      </div>
    <?php endif; ?>
  </main>
</body>
</html>
