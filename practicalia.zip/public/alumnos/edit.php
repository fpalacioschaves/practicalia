<?php
// practicalia/public/alumnos/edit.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_staff.php';
require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$isAdmin = require_role('admin');
$profId  = (int)($user['id'] ?? 0);

$idGet  = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$idPost = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$id     = $idPost ?: $idGet;
if (!$id || $id <= 0) { http_response_code(400); exit('ID inválido'); }

$error = '';

/** Verifica acceso (profe solo ve alumnos de sus cursos) */
if (!$isAdmin) {
  $stChk = $pdo->prepare("
    SELECT 1
    FROM alumnos a
    JOIN alumnos_cursos ac ON ac.alumno_id = a.id
    JOIN cursos_profesores cp ON cp.curso_id = ac.curso_id AND cp.profesor_id = :pid
    WHERE a.id = :id AND a.deleted_at IS NULL
    LIMIT 1
  ");
  $stChk->execute([':pid'=>$profId, ':id'=>$id]);
  if (!$stChk->fetch()) { http_response_code(403); exit('No tienes acceso a este alumno.'); }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['accion'] ?? '') === 'guardar_alumno')) {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $nombre    = trim($_POST['nombre'] ?? '');
    $apellidos = trim($_POST['apellidos'] ?? '');
    $email     = trim($_POST['email'] ?? '');
    $telefono  = trim($_POST['telefono'] ?? '');
    $activo    = (isset($_POST['activo']) && $_POST['activo'] === '1') ? 1 : 0;
    $cursoId   = (int)($_POST['curso_id'] ?? 0);
    $fnac      = trim($_POST['fecha_nacimiento'] ?? '');
    $notas     = trim($_POST['notas'] ?? '');

    if ($nombre === '' || $apellidos === '') throw new RuntimeException('Nombre y apellidos son obligatorios.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Email no válido.');
    if ($fnac !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $fnac)) throw new RuntimeException('Fecha de nacimiento inválida (YYYY-MM-DD).');

    // Email único (permitiendo el actual)
    if ($email !== '') {
      $stChk = $pdo->prepare("SELECT 1 FROM alumnos WHERE email = :e AND id <> :id AND deleted_at IS NULL LIMIT 1");
      $stChk->execute([':e'=>$email, ':id'=>$id]);
      if ($stChk->fetch()) throw new RuntimeException('Ya existe otro alumno con ese email.');
    }

    // Validar permiso del curso elegido (si no es admin)
    if ($cursoId > 0 && !$isAdmin) {
      $st2 = $pdo->prepare("SELECT 1 FROM cursos_profesores WHERE curso_id = :c AND profesor_id = :p LIMIT 1");
      $st2->execute([':c'=>$cursoId, ':p'=>$profId]);
      if (!$st2->fetch()) throw new RuntimeException('No puedes asignar ese curso.');
    }

    // Update alumno (incluye fecha_nacimiento y notas)
    $st = $pdo->prepare("
      UPDATE alumnos
      SET nombre=:n, apellidos=:a, email=:e, telefono=:t, activo=:ac, fecha_nacimiento=:fn, notas=:no
      WHERE id=:id
    ");
    $st->execute([
      ':n'=>$nombre,
      ':a'=>$apellidos,
      ':e'=>($email!=='' ? $email : null),
      ':t'=>($telefono!=='' ? $telefono : null),
      ':ac'=>$activo,
      ':fn'=>($fnac!=='' ? $fnac : null),
      ':no'=>($notas!=='' ? $notas : null),
      ':id'=>$id
    ]);

    // Curso único: limpiamos y re-asignamos (si procede)
    $pdo->prepare('DELETE FROM alumnos_cursos WHERE alumno_id = :id')->execute([':id'=>$id]);
    if ($cursoId > 0) {
      $ins = $pdo->prepare("
        INSERT INTO alumnos_cursos (alumno_id, curso_id, fecha_inicio, estado)
        VALUES (:al,:cu, CURDATE(), 'matriculado')
      ");
      $ins->execute([':al'=>$id, ':cu'=>$cursoId]);
    }

    header('Location: ./edit.php?id='.$id);
    exit;

  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}

// Carga alumno
$stA = $pdo->prepare('
  SELECT id, nombre, apellidos, email, telefono, COALESCE(activo,1) AS activo, fecha_nacimiento, notas
  FROM alumnos WHERE id=:id AND deleted_at IS NULL LIMIT 1
');
$stA->execute([':id'=>$id]);
$al = $stA->fetch();
if (!$al) { http_response_code(404); exit('Alumno no encontrado'); }
$alActivo = (int)$al['activo'];

// Curso actual (si lo hubiera)
$stAC = $pdo->prepare('SELECT curso_id FROM alumnos_cursos WHERE alumno_id = :id ORDER BY id DESC LIMIT 1');
$stAC->execute([':id'=>$id]);
$cursoActual = (int)($stAC->fetch()['curso_id'] ?? 0);

// Cursos disponibles (según rol)
if ($isAdmin) {
  $cursos = $pdo->query("SELECT id, nombre FROM cursos ORDER BY nombre")->fetchAll();
} else {
  $stC = $pdo->prepare("
    SELECT c.id, c.nombre
    FROM cursos c
    JOIN cursos_profesores cp ON cp.curso_id = c.id AND cp.profesor_id = :pid
    ORDER BY c.nombre
  ");
  $stC->execute([':pid'=>$profId]);
  $cursos = $stC->fetchAll();
}

// Contactos del alumno (si usas el diario)
$stCt = $pdo->prepare('
  SELECT ac.id, ac.fecha, ac.tipo, ac.resumen, ac.notas,
         u.id AS prof_id, u.nombre AS prof_nombre, u.apellidos AS prof_apellidos
  FROM alumno_contactos ac
  JOIN usuarios u ON u.id = ac.profesor_id
  WHERE ac.alumno_id = :id
  ORDER BY ac.fecha DESC, ac.id DESC
');
$stCt->execute([':id'=>$id]);
$contactos = $stCt->fetchAll();
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Editar alumno — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-6xl mx-auto p-4">
    <h1 class="text-xl font-semibold mb-4">Editar alumno #<?= (int)$al['id'] ?> — <?= htmlspecialchars($al['nombre'] . ' ' . $al['apellidos']) ?></h1>

    <?php if ($error): ?>
      <div class="mb-3 bg-red-50 text-red-700 p-3 rounded"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- FORM ALUMNO -->
    <form method="post" class="bg-white p-6 rounded-2xl shadow space-y-4 mb-8">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
      <input type="hidden" name="id" value="<?= (int)$al['id'] ?>">
      <input type="hidden" name="accion" value="guardar_alumno">

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Nombre *</label>
          <input name="nombre" value="<?= htmlspecialchars($al['nombre']) ?>" required class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Apellidos *</label>
          <input name="apellidos" value="<?= htmlspecialchars($al['apellidos']) ?>" required class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Email</label>
          <input name="email" type="email" value="<?= htmlspecialchars($al['email'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Teléfono</label>
          <input name="telefono" value="<?= htmlspecialchars($al['telefono'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
      </div>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="block text-sm font-medium">Fecha de nacimiento</label>
          <input name="fecha_nacimiento" type="date" value="<?= htmlspecialchars($al['fecha_nacimiento'] ?? '') ?>" class="mt-1 w-full border rounded-xl p-2">
        </div>
        <div>
          <label class="block text-sm font-medium">Curso</label>
          <select name="curso_id" class="mt-1 w-full border rounded-xl p-2">
            <option value="0">— Sin curso —</option>
            <?php foreach ($cursos as $c): $cid=(int)$c['id']; ?>
              <option value="<?= $cid ?>" <?= ($cid === $cursoActual) ? 'selected' : '' ?>>
                <?= htmlspecialchars($c['nombre']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium">Notas</label>
        <textarea name="notas" rows="4" class="mt-1 w-full border rounded-xl p-2"><?= htmlspecialchars($al['notas'] ?? '') ?></textarea>
      </div>

      <div class="flex items-center gap-2">
        <input type="hidden" name="activo" value="0">
        <input type="checkbox" name="activo" id="activo" value="1" <?= ($alActivo===1)?'checked':'' ?>>
        <label for="activo" class="text-sm">Alumno activo</label>
      </div>

      <div class="flex gap-2">
        <button class="rounded-xl bg-black text-white px-4 py-2">Guardar</button>
        <a href="./index.php" class="rounded-xl px-4 py-2 border">Cancelar</a>
      </div>
    </form>

    <!-- DIARIO DE CONTACTOS (si lo estás usando) -->
    <section class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Diario de contactos</h2>
        <ul class="space-y-3">
          <?php foreach ($contactos as $c): ?>
            <li class="border rounded-xl p-3">
              <div class="flex items-center justify-between text-sm">
                <div>
                  <span class="font-medium"><?= htmlspecialchars($c['prof_apellidos'] . ', ' . $c['prof_nombre']) ?></span>
                  · <span class="text-gray-500"><?= htmlspecialchars($c['tipo']) ?></span>
                  · <span class="text-gray-500"><?= htmlspecialchars($c['fecha']) ?></span>
                </div>
                <?php if ($isAdmin || (int)$c['prof_id'] === $profId): ?>
                  <form method="post" action="./contacto_delete.php" onsubmit="return confirm('¿Eliminar contacto?');">
                    <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="alumno_id" value="<?= (int)$al['id'] ?>">
                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                    <button class="text-red-600 underline text-xs">Eliminar</button>
                  </form>
                <?php endif; ?>
              </div>
              <div class="mt-2 font-medium"><?= htmlspecialchars($c['resumen']) ?></div>
              <?php if (!empty($c['notas'])): ?>
                <div class="mt-1 text-sm text-gray-700 whitespace-pre-line"><?= htmlspecialchars($c['notas']) ?></div>
              <?php endif; ?>
            </li>
          <?php endforeach; ?>
          <?php if (!$contactos): ?>
            <li class="text-sm text-gray-500">Aún no hay contactos.</li>
          <?php endif; ?>
        </ul>
      </div>

      <div class="bg-white p-6 rounded-2xl shadow">
        <h2 class="font-semibold mb-3">Añadir contacto</h2>
        <form method="post" action="./contacto_create.php" class="space-y-3">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">
          <input type="hidden" name="alumno_id" value="<?= (int)$al['id'] ?>">

          <div>
            <label class="block text-sm font-medium">Tipo</label>
            <select name="tipo" class="mt-1 w-full border rounded-xl p-2">
              <option value="llamada">Llamada</option>
              <option value="email">Email</option>
              <option value="tutoria">Tutoría</option>
              <option value="visita">Visita</option>
              <option value="otro">Otro</option>
            </select>
          </div>

          <div>
            <label class="block text-sm font-medium">Resumen *</label>
            <input name="resumen" required class="mt-1 w-full border rounded-xl p-2" placeholder="Asunto breve">
          </div>

          <div>
            <label class="block text-sm font-medium">Notas</label>
            <textarea name="notas" rows="4" class="mt-1 w-full border rounded-xl p-2" placeholder="Detalles..."></textarea>
          </div>

          <button class="rounded-xl bg-black text-white px-4 py-2">Guardar contacto</button>
        </form>
      </div>
    </section>
  </main>
</body>
</html>
