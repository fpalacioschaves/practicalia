<?php
// practicalia/public/perfil/edit.php
declare(strict_types=1);

require_once __DIR__ . '/../../middleware/require_auth.php';
require_once __DIR__ . '/../../lib/auth.php';

$user = current_user();
$id = (int)$user['id'];

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    csrf_check($_POST['csrf'] ?? null);

    $nombre  = trim($_POST['nombre'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $pass    = trim($_POST['password'] ?? '');

    if ($nombre === '' || $email === '') {
      throw new RuntimeException('El nombre y el email son obligatorios.');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      throw new RuntimeException('El email no es válido.');
    }

    if ($pass !== '') {
      $hash = password_hash($pass, PASSWORD_DEFAULT);
      $st = $pdo->prepare('UPDATE usuarios SET nombre=:n, email=:e, password_hash=:p WHERE id=:id');
      $st->execute([':n'=>$nombre, ':e'=>$email, ':p'=>$hash, ':id'=>$id]);
    } else {
      $st = $pdo->prepare('UPDATE usuarios SET nombre=:n, email=:e WHERE id=:id');
      $st->execute([':n'=>$nombre, ':e'=>$email, ':id'=>$id]);
    }

    $_SESSION['user']['nombre'] = $nombre;
    $_SESSION['user']['email']  = $email;

    $success = 'Perfil actualizado correctamente.';

  } catch (Throwable $e) {
    $error = $e->getMessage();
  }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Mi perfil — Practicalia</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">
  <?php require_once __DIR__ . '/../partials/menu.php'; ?>

  <main class="max-w-lg mx-auto p-6">
    <h1 class="text-xl font-semibold mb-4">Mi perfil</h1>

    <?php if ($error): ?>
      <div class="mb-3 bg-red-50 text-red-700 p-3 rounded"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
      <div class="mb-3 bg-green-50 text-green-700 p-3 rounded"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="post" class="bg-white p-6 rounded-2xl shadow space-y-4">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>">

      <div>
        <label class="block text-sm font-medium">Nombre completo</label>
        <input name="nombre" value="<?= htmlspecialchars($user['nombre'] ?? '') ?>" required class="mt-1 w-full border rounded-xl p-2">
      </div>

      <div>
        <label class="block text-sm font-medium">Email</label>
        <input name="email" type="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" required class="mt-1 w-full border rounded-xl p-2">
      </div>

      <div>
        <label class="block text-sm font-medium">Contraseña (dejar en blanco para no cambiar)</label>
        <input name="password" type="password" class="mt-1 w-full border rounded-xl p-2">
      </div>

      <div class="flex gap-2">
        <button class="rounded-xl bg-black text-white px-4 py-2">Guardar</button>
        <a href="<?= $base ?>/index.php" class="rounded-xl border px-4 py-2">Cancelar</a>
      </div>
    </form>
  </main>
</body>
</html>
